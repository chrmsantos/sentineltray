"""CLI command queue removed."""
